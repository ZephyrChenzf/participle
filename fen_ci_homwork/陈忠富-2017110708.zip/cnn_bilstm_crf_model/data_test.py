# -*- coding: utf-8 -*-
import numpy as np

import data

#data.make_test_normal('./data/test.txt')
print data.dict_tag