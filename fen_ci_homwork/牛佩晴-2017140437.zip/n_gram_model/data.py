# -*- coding: utf-8 -*-
import numpy as np
import pickle

word_count_dict=pickle.load(open('./data/word_count_dict.pkl','rb'))
word_word_count_dict=pickle.load(open('./data/word_word_count_dict.pkl','rb'))
